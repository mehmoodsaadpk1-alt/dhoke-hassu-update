import { useMemo, useEffect, useRef } from 'react';
import { useAdStore } from '../store/adStore';
import { AdItem } from '../types';

export function useAdRotator(
  placement: string,
  itemCount: number,
  interval: number = 5,
  formatFilter?: 'Feed' | 'Banner'
): Record<number, AdItem> {
  const { fetchAdsForPlacement, ads } = useAdStore();

  const placementAds = useMemo(() => {
    const rawAds = (ads[placement] || []).filter(ad => ad.format !== 'Popup');
    if (formatFilter === 'Banner') {
      return rawAds.filter(ad => ad.format === 'Banner');
    }
    if (formatFilter === 'Feed') {
      // Treat undefined/null format as Feed (Standard) ad by default
      return rawAds.filter(ad => !ad.format || ad.format === 'Feed');
    }
    return rawAds;
  }, [ads, placement, formatFilter]);

  const assignmentsRef = useRef<Record<number, AdItem>>({});
  const initialCursorRef = useRef<number | null>(null);

  // Trigger fetch when placement changes
  useEffect(() => {
    try {
      fetchAdsForPlacement(placement);
    } catch (err) {
      console.warn(`[AdSystem] Failed to fetch ads for ${placement}:`, err);
    }
  }, [placement, fetchAdsForPlacement]);

  const adMap = useMemo(() => {
    if (placementAds.length === 0 || itemCount === 0 || interval <= 0) return assignmentsRef.current;

    // Load initial cursor once per component lifecycle
    const cursorKey = `dhoke_ad_cursor_${placement}`;
    if (initialCursorRef.current === null) {
      const stored = parseInt(localStorage.getItem(cursorKey) || '0', 10);
      initialCursorRef.current = isNaN(stored) ? 0 : stored;
    }
    
    let currentCursor = initialCursorRef.current;
    let newAssignmentsAdded = false;

    // Generate insertions only for indices we haven't assigned yet
    for (let i = 0; i < itemCount; i++) {
      if ((i + 1) % interval === 0) {
        if (!assignmentsRef.current[i]) {
          // It's time to assign a new ad for this index
          const checkIndex = currentCursor % placementAds.length;
          const selectedAd = placementAds[checkIndex];
          
          assignmentsRef.current[i] = selectedAd;
          newAssignmentsAdded = true;

          const nextCursor = (currentCursor + 1) % placementAds.length;

          console.log(`[ADS] Placement: ${placement}`);
          console.log(`[ADS] Total active ads: ${placementAds.length}`);
          console.log(`[ADS] Queue:`, placementAds.map(a => a.id));
          console.log(`[ADS] Current cursor: ${currentCursor}`);
          console.log(`[ADS] Selected ad: ${selectedAd.title} (${selectedAd.id})`);
          console.log(`[ADS] Next cursor: ${nextCursor}`);
          console.log(`[ADS] Feed insertion index: ${i}`);

          currentCursor = nextCursor;
        }
      }
    }

    // If we advanced the cursor, save it back so the next page visit starts from the new position
    if (newAssignmentsAdded) {
      initialCursorRef.current = currentCursor;
      localStorage.setItem(cursorKey, currentCursor.toString());
    }

    return { ...assignmentsRef.current };
  }, [placement, placementAds, itemCount, interval]);

  return adMap;
}
